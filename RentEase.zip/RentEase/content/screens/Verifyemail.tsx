import { View, Text } from 'react-native'
import React from 'react'

const Verifyemail = () => {
  return (
    <View>
      <Text>Please verify your xxx</Text>
    </View>
  )
}

export default Verifyemail;
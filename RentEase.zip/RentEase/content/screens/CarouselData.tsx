const CarouselData = [
    {
      title: "",
      body: ".",
     
       image: require('../images/slider1.jpeg')
    },
    {
      title: "",
      body: " ",
      image: require('../images/slider1.jpeg')
    },
    {
      title: "",
      body: "",
      image: require('../images/slider1.jpeg')
    },
  ];
  
  export default CarouselData;